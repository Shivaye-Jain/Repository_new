#include <stdio.h>
#include "complex.h"
#include <string.h>
#include <stdlib.h>

#define MAX_COMMAND_LENGTH 20

int main()
{
    char temp[MAX_COMMAND_LENGTH];

    printf("Which operations would you like to do with complex number(s)?\n");
    for (int i = 0; i < 5; i++)
    {
        switch (i)
        {
        case 0:
            printf("ADD\n");
            break;
        case 1:
            printf("SUB\n");
            break;
        case 2:
            printf("MOD\n");
            break;
        case 3:
            printf("DOT\n");
            break;
        case 4:
            printf("COS\n");
            break;
        }
    }

    printf("Enter exit to exit the program:\n");

L1:
    scanf("%s", temp);
    if (strcmp(temp, "exit") == 0)
    {
        exit(0);
    }
    else if (strcmp(temp, "ADD") == 0)
    {
        complex *c1 = createComplex();
        complex *c2 = createComplex();
        int n;
        scanf("%d", &n);
        for (int i = 0; i < n; i++)
        {
            float a;
            scanf("%f", &a);
            insertNode(c1, a);
        }
        for (int i = 0; i < n; i++)
        {
            float a;
            scanf("%f", &a);
            insertNode(c2, a);
        }
        complex *c3 = add(c1, c2);
        printcomplex(c3);
        goto L1;
    }
    else if (strcmp(temp, "SUB") == 0)
    {
        complex *c1 = createComplex();
        complex *c2 = createComplex();
        int n;
        scanf("%d", &n);
        for (int i = 0; i < n; i++)
        {
            float a;
            scanf("%f", &a);
            insertNode(c1, a);
        }
        for (int i = 0; i < n; i++)
        {
            float a;
            scanf("%f", &a);
            insertNode(c2, a);
        }
        complex *c3 = sub(c1, c2);
        printcomplex(c3);
        goto L1;
    }
    else if (strcmp(temp, "MOD") == 0)
    {
        complex *c1 = createComplex();
        int n;
        scanf("%d", &n);
        for (int i = 0; i < n; i++)
        {
            float a;
            scanf("%f", &a);
            insertNode(c1, a);
        }
        printf("%.2f\n", mod(c1));
        goto L1;
    }
    else if (strcmp(temp, "DOT") == 0)
    {
        complex *c1 = createComplex();
        complex *c2 = createComplex();
        int n;
        scanf("%d", &n);
        for (int i = 0; i < n; i++)
        {
            float a;
            scanf("%f", &a);
            insertNode(c1, a);
        }
        for (int i = 0; i < n; i++)
        {
            float a;
            scanf("%f", &a);
            insertNode(c2, a);
        }
        printf("%.2f\n", dot(c1, c2));
        goto L1;
    }
    else if (strcmp(temp, "COS") == 0)
    {
        complex *c1 = createComplex();
        complex *c2 = createComplex();
        int n;
        scanf("%d", &n);
        for (int i = 0; i < n; i++)
        {
            float a;
            scanf("%f", &a);
            insertNode(c1, a);
        }
        for (int i = 0; i < n; i++)
        {
            float a;
            scanf("%f", &a);
            insertNode(c2, a);
        }
        printf("%.2f\n", COS(c1, c2));
        goto L1;
    }
    else
    {
        printf("Invalid input\n");
        goto L1;
    }

    return 0;
}