#include <math.h>
#include <stdlib.h>
#include "complex.h"
#include <stdio.h>
#include <assert.h>

Node *createNode()
{
    Node *newnode = (Node *)malloc(sizeof(Node));
    assert(newnode != NULL);
    newnode->next = NULL;
    return newnode;
}

complex *createComplex()
{
    complex *Complex = (complex *)malloc(sizeof(complex));
    assert(Complex != NULL);
    Complex->head = NULL;
    return Complex;
}

Node *insertNode(complex *c, float x)
{
    if (c->head != NULL)
    {
        for (Node *start = c->head; start != NULL; start = start->next)
        {
            if (start->next == NULL)
            {
                start->next = createNode();
                start->next->a = x;
                return start->next;
            }
        }
    }
    else
    {
        c->head = createNode();
        c->head->a = x;
        return c->head;
    }
}

complex *add(complex *a, complex *b)
{
    complex *c;
    c = createComplex();
    for (Node *start = a->head, *start2 = b->head; start != NULL; start = start->next)
    {
        insertNode(c, start->a + start2->a);
        start2 = start2->next;
    }

    return c;
}

complex *sub(complex *a, complex *b)
{
    complex *c;
    c = createComplex();
    Node *start2 = b->head;
    for (Node *start = a->head; start != NULL; start = start->next)
    {
        insertNode(c, start->a - start2->a);
        start2 = start2->next;
    }

    return c;
}

float mod(complex *a)
{
    int i = 0;
    for (Node *start = a->head; start != NULL; start = start->next)
    {
        i += ((start->a) * (start->a));
    }
    float MOD = sqrt(i);
    return MOD;
}

float dot(complex *a, complex *b)
{
    float dot_p;
    for (Node *start = a->head, *start2 = b->head; start != NULL; start = start->next, start2 = start2->next)
    {
        dot_p += start->a * start2->a;
    }

    return dot_p;
}

float COS(complex *a, complex *b)
{
    return dot(a, b)/(mod(a) * mod(b)); 
}

void printcomplex(complex *c)
{
    for (Node *start = c->head; start != NULL; start = start->next)
    {
        printf("%lf ", start->a);
    }
    printf("\n");
} 