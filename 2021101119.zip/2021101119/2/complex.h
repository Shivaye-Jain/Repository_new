#ifndef __COMPLEX_H
#define __COMPLEX_H

typedef struct node
{
    float a;
    struct node *next;
}Node;

typedef struct complex
{
    Node *head;
}complex;

Node *createNode();
complex *createComplex();
Node *insertNode(complex *, float);
complex *add(complex *, complex *);
complex *sub(complex *, complex *);
float mod(complex *);
float dot(complex *, complex *);
float COS(complex *, complex *);
void printcomplex(complex *);

#endif