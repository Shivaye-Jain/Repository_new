#ifndef __SONG_H
#define __SONG_H

typedef struct Song
{
    char *name;
    char *artist;
    float duration;
    struct Song *next;
}song;

song *makeSong(char *, char *, float);

#endif