#include <stdlib.h>
#include "musicplayer.h"
#include <assert.h>

musicPlayer *createMusicPlayer()
{
    musicPlayer *music = (musicPlayer *)malloc(sizeof(musicPlayer));
    assert(music != NULL);
    music->current_song = NULL;
    music->queue_front = NULL;
    music->queue_end = NULL;

    return music;
}

int addSongToQueue(musicPlayer *music, song *songs)
{
    if (get_queue_size(music) <= 99)
    {
        song *newsong = makeSong(songs->name, songs->artist, songs->duration);
        if (music->queue_front == NULL)
        {
            music->queue_front = newsong;
            music->queue_end = newsong;
        }
        else
        {
            music->queue_end->next = newsong;
            music->queue_end = newsong;
        }
        return 0;
    }
    else
    {
        return 1;
    }
}

int removeSongFromQueue(musicPlayer *music, int x)
{
    if (get_queue_size(music) == 0)
    {
        return 1;
    }
    else
    {
        if (x == 0 && get_queue_size(music) == 1)
        {
            music->queue_end = NULL;
            music->queue_front = NULL;
        }
        else if (x == 0 && get_queue_size(music) > 1)
        {
            music->queue_front = music->queue_front->next;
        }
        else if (x != 0 && x != get_queue_size(music) - 1)
        {
            int i = -1;
            for (song *start = music->queue_front; start->next != NULL; start = start->next)
            {
                i++;
                if (i == x - 1)
                {
                    start->next = start->next->next;
                }
            }
        }
        else if (x == get_queue_size(music) - 1)
        {
            int i = -1;
            for (song *start = music->queue_front; start->next != NULL; start = start->next)
            {
                i++;
                if (i == x - 1)
                {
                    music->queue_end = start;
                    start->next = NULL;
                }
            }
        }
        return 0;
    }
}

int playSong(musicPlayer *music)
{
    if (get_queue_size(music) > 0)
    {
        music->current_song = music->queue_front;
        if (get_queue_size(music) == 1)
        {
            music->queue_end = NULL;
            music->queue_front = NULL;
        }
        else
        {
            music->queue_front = music->queue_front->next;
        }
        return 0;
    }
    else
    {
        return 1;
    }
}

song *getCurrentSong(musicPlayer *music)
{
    return music->current_song;
}

int get_queue_size(musicPlayer *music)
{
    int i = 0;
    for (song *start = music->queue_front; start != NULL; start = start->next)
    {
        i++;
    }

    return i;
}