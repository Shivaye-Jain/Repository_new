#include "song.h"
#include"musicplayer.h"
#include <stdlib.h>
#include <assert.h>

song *makeSong(char *name, char *artist, float duration)
{
    song *newsong = (song *)malloc(sizeof(song));
    assert(newsong != NULL);
    newsong->name = name;
    newsong->artist = artist;
    newsong->duration = duration;
    newsong->next = NULL;

    return newsong;
}