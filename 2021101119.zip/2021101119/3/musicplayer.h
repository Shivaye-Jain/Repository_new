#ifndef __MUSICPLAYER_H
#define __MUSICPLAYER_H

#include "song.h"

typedef struct MusicPlayer
{
    song *current_song;
    song *queue_front;
    song *queue_end;
} musicPlayer;

musicPlayer *createMusicPlayer();
int addSongToQueue(musicPlayer *, song *);
int removeSongFromQueue(musicPlayer *, int);
int playSong(musicPlayer *);
song *getCurrentSong(musicPlayer *);
int get_queue_size(musicPlayer *);

#endif