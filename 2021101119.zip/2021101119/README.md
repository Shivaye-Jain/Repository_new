# **Assumptions and I/O choices**
> **Compile all the solutions using command 'make all'.**
## 1) **1st Question**
1. To run the executable give command './q1.out'.
2. I have designed a command line interface asking user what operation he/she would like to do giving a list of the operations.
3. Enter 'exit' to exit the program.
4. I have kept same functions as mentioned adding some more functions for implementation.
5. Commands for the operations is same as given in the sample test case.
## 2) **2nd Question**
1. To run the executable give command './q2.out'.
2. I have designed a command line interface asking user what operation he/she would like to do giving a list of the operations.
3. Enter 'exit' to exit the program.
4. I have kept same functions as mentioned adding some more functions for implementation.
5. Commands for the operations is same as given in the sample test case.
## 3) **3rd Question**
1. To run the executable give command './q3.out'.
2. I have copied the driver code in 'main.c' file.
3. I have kept same functions as mentioned adding some more functions for implementation.
4. Commands for the operations is same as given in the sample run of driver code.
5. I have **NOT** done the bonus part of this question.
