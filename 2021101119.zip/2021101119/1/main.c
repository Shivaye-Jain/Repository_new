#include <stdio.h>
#include "my_dll.h"
#include <stdlib.h>
#include <string.h>

#define MAX_COMMAND_LENGTH 20

int main()
{
    my_dll *list = createList();
    int i1, i2;
    char temp[MAX_COMMAND_LENGTH];

    printf("Which operations would you like to do in a doubly linked list of integers?\n");
    for (int i = 0; i < 8; i++)
    {
        switch (i)
        {
        case 0:
            printf("insert\n");
            break;
        case 1:
            printf("insert_at\n");
            break;
        case 2:
            printf("print\n");
            break;
        case 3:
            printf("prune\n");
            break;
        case 4:
            printf("print_reverse\n");
            break;
        case 5:
            printf("get_size\n");
            break;
        case 6:
            printf("delete\n");
            break;
        case 7:
            printf("find\n");
            break;
        }
    }

    printf("Enter exit to exit the program:\n");
L1:
    scanf("%s", temp);
    if (strcmp(temp, "exit") == 0)
    {
        exit(0);
    }
    else if (strcmp(temp, "insert") == 0)
    {
        scanf("%d", &i1);
        insert(list, i1);
        goto L1;
    }
    else if (strcmp(temp, "insert_at") == 0)
    {
        scanf("%d %d", &i1, &i2);
        insert_at(list, i1, i2);
        goto L1;
    }
    else if (strcmp(temp, "print") == 0)
    {
        print(list);
        printf("\n");
        goto L1;
    }
    else if (strcmp(temp, "prune") == 0)
    {
        prune(list);
        goto L1;
    }
    else if (strcmp(temp, "print_reverse") == 0)
    {
        print_reverse(list);
        printf("\n");
        goto L1;
    }
    else if (strcmp(temp, "get_size") == 0)
    {
        printf("%d\n", get_size(list));
        goto L1;
    }
    else if (strcmp(temp, "delete") == 0)
    {
        scanf("%d", &i1);
        delete (list, i1);
        goto L1;
    }
    else if (strcmp(temp, "find") == 0)
    {
        scanf("%d", &i1);
        printf("%d\n", find(list, i1));
        goto L1;
    }
    else
    {
        printf("Invalid input\n");
        goto L1;
    }

    return 0;
}