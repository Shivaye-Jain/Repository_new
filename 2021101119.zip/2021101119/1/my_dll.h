#ifndef __MY_DLL_H
#define __MY_DLL_H

#include "node.h"

typedef struct my_dll
{
    node *root;
    node *top;
}my_dll;

my_dll* createList(); 
void insert(my_dll*, int);
void insert_at(my_dll*, int, int);
void delete(my_dll*, int);
int find(my_dll*, int);
void prune(my_dll*);
void print(my_dll*);
void print_reverse(my_dll*);
int get_size(my_dll*);

#endif