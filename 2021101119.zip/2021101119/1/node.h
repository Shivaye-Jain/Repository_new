#ifndef __NODE_H
#define __NODE_H

typedef struct node
{
    int data;
    struct node *prev;
    struct node *next;
}node;

node *createNode();

#endif