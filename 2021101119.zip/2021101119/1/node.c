#include <stdlib.h>
#include "node.h"
#include <assert.h>

node *createNode()
{
    node *newnode = (node *)malloc(sizeof(node));
    assert(newnode != NULL);
    newnode->next = NULL;
    newnode->prev = NULL;
    return newnode;
}
