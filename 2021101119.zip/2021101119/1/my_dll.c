#include "my_dll.h"
#include <stdlib.h>
#include <stdio.h>
#include <assert.h>

my_dll *createList()
{
    my_dll *list = (my_dll *)malloc(sizeof(my_dll));
    assert(list != NULL);
    list->root = NULL;
    list->top = NULL;
    return list;
}

void insert(my_dll *list, int x)
{
    if ((list->root) != NULL)
    {
        node *newnode = createNode();
        newnode->data = x;
        ((list->top)->next) = newnode;
        newnode->prev = list->top;
        list->top = newnode;
    }
    else
    {
        node *newnode = createNode();
        newnode->data = x;
        list->root = newnode;
        list->top = newnode;
    }
}

void insert_at(my_dll *list, int x, int i)
{
    int j = -1;
    if (i != 0)
    {
        for (node *finger = list->root; j != i - 1; finger = finger->next)
        {
            j++;
            if (j == i - 1)
            {
                if (finger->next != NULL)
                {
                    node *newnode = createNode();
                    newnode->data = x;
                    newnode->prev = finger;
                    newnode->next = finger->next;
                    (finger->next)->prev = newnode;
                    finger->next = newnode;
                }
                else
                {
                    insert(list, x);
                }
            }
        }
    }
    else if (i == 0 && list->root == NULL)
    {
        insert(list, x);
    }
    else if (i == 0 && list->root != NULL)
    {
        node *newnode = createNode();
        newnode->next = list->root;
        newnode->data = x;
        (newnode->next)->prev = newnode;
        list->root = newnode;
    }
}

void delete (my_dll *list, int i)
{
    int j = -1;
    if (i != 0)
    {
        for (node *finger = list->root; j != i; finger = finger->next)
        {
            j++;
            if (j == i)
            {
                if (finger->next != NULL)
                {
                    (finger->prev)->next = finger->next;
                    (finger->next)->prev = finger->prev;
                    free(finger);
                    return;
                }
                else
                {
                    list->top = finger->prev;
                    (finger->prev)->next = NULL;
                    free(finger);
                    return;
                }
            }
        }
    }
    else if (i == 0 && list->root->next != NULL)
    {
        list->root = list->root->next;
        (list->root)->prev = NULL;
    }
    else if (i == 0 && list->root->next == NULL)
    {
        free(list->root);
        list->root = NULL;
        list->top = NULL;
    }
}

int find(my_dll *list, int x)
{
    int j = -1;
    for (node *finger = list->root; finger != NULL; finger = finger->next)
    {
        j++;
        if (finger->data == x)
        {
            return j;
        }
    }

    return -1;
}

void prune(my_dll *list)
{
    int j = -1;
    for (node *finger = list->root; finger != NULL; finger = finger->next)
    {
        j++;
        if (j % 2 != 0)
        {
            if (finger->next != NULL)
            {
                (finger->prev)->next = finger->next;
                (finger->next)->prev = finger->prev;
                free(finger);
            }
            else
            {
                list->top = finger->prev;
                (finger->prev)->next = NULL;
                free(finger);
            }
        }
    }
}

void print(my_dll *list)
{
    for (node *finger = list->root; finger != NULL; finger = finger->next)
    {
        printf("%d ", finger->data);
    }
}

void print_reverse(my_dll *list)
{
    for (node *finger = list->top; finger != NULL; finger = finger->prev)
    {
        printf("%d ", finger->data);
    }
}

int get_size(my_dll *list)
{
    int j = -1;
    for (node *finger = list->root; finger != NULL; finger = finger->next)
    {
        j++;
    }
    return j + 1;
}