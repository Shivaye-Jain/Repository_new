#!/bin/bash
echo "Enter file name:"
read file
echo >> $file
line_no=0
file=$file
while IFS= read -r line
do
    let line_no++
    var=$(wc -w <<< "$line")
    echo "Line No: $line_no - Count of Words: $var"
done < $file
perl -i -pe "chomp if eof" $file