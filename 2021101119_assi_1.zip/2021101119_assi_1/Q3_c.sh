#!/bin/bash
echo "Enter file name:"
read file
wc -w < $file