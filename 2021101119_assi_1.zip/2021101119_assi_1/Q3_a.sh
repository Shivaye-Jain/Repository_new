#!/bin/bash
echo "Enter file name:"
read file
stat --printf="%s" $file
echo