Notes for the evaluators:
a) 1st question
1. Run the file using the command './Q1.sh'.
b) 2nd question
1. Run the file using the command './Q2.sh'.
c) 3rd question
1. Run the file using the command './Q3.sh'.
2. Enter the file name
d) 4th question
1. Run the file using the command './Q4.sh'.
2. Enter the numbers to be sorted.
e) 5th question
1. Run the file using the command './Q5.sh'.
2. Enter the string

Git repository link:
https://github.com/Shivaye-Jain/New_Repository
