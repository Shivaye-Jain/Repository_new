#!/bin/bash
echo "Enter file name:"
read file2
grep -wo '[[:alnum:]]\+' $file2 | sort | uniq -cd > temp.txt
file=temp.txt
while IFS= read -r line
do
a=$line
arr=($a)
var1=${arr[@]:0:1}
var2=${arr[@]:1:2}
echo "Word: $var2 - Count of repetition: $var1"
done < $file
rm temp.txt