#!/bin/bash
echo "Enter file name:"
read file
no_lines=$(wc -l < $file)
let no_lines++
echo $no_lines