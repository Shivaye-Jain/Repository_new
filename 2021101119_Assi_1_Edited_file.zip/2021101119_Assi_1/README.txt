Notes for the evaluators:
a) 1st question
1. Run the file using the command './Q1.sh'.
2. The file quotes.txt should be present in the same directory as the 'Q1.sh'. 
b) 2nd question
1. Run the file using the command './Q2.sh'.
2. The file quotes.txt should be present in the same directory as the 'Q2.sh'.
c) 3rd question
1. Run the files using the command './Q3_<partname>.sh'.(where 'partname' can be 'a', 'b', 'c', 'd' or 'e').
2. Enter the file name as the prompt asks.
d) 4th question
1. Run the file using the command './Q4.sh'.
2. Enter the numbers to be sorted.
e) 5th question
1. Run the file using the command './Q5.sh'.
2. Enter the string first for the a part and b part.
3. Enter another string for the c part.

Git repository link:
https://github.com/Shivaye-Jain/Repository_new